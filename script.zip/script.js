function main() {

    createCards();

}
let task = [{
        taskName: "Cleaning",
        descriptioe: "Cleaning the living area",
        importance: 0,
        pic: "images\\img2.jpg",


    },
    {
        taskName: "dishes",
        description: "dishes on a regular basis",
        importance: 0,
        pic: "images\\img3.jpg"


    },
    {
        taskName: "VaccumCleaning",
        description: "Cleaning the bedroom",
        importance: 0,
        pic: "images\\img4.jpg"
    },
    {
        taskName: "Cooking",
        description: "Cleaning with grandmother",
        importance: 0,
        pic: "images\\img5.jpg"

    },
    {
        taskName: "Vaccum",
        description: "Cleaning the living area",
        importance: 0,
        pic: "images\\img6.jpg"

    },
    {
        etaskName: "Grocery",
        descriptioe: "Grocery shopping for the week",
        importance: 0,
        pic: "images\\img7.jpg"
    },
    {
        taskName: "Playtime",
        description: "Playing with the kids",
        importance: 0,
        pic: "images\\img8.jpg"


    },
    {
        taskName: "Vaccum",
        description: "Cleaning the living area",
        importance: 0,
        pic: "images\\img9.jpg"

    },
    {
        taskName: "Vaccum",
        description: "Cleaning the living area",
        importance: 0,
        pic: "images\\img10.jpg"

    },
];
main();

function createCards() {
    for (let val of task) {
        document.getElementById("result").innerHTML += `
    <div>
<div class="card" style="width: 18rem;">
<img src="${val.pic}" class="card-img-top" alt="...">
<div class="card-body">
  <h5 class="card-title">${val.taskName}</h5>
  <p class="likes">${val.description}</p>
  <a href="#" class="btn btn-secondary btn-sm importancebtn">importance</a>
  <p class="importance">${val.importance}</p>
  <a href="#" class="btn btn-success ">done</a>
  <a href="#" class="btn btn-danger ">delete</a>
</div>
</div>
</div>`;

    }
}

// function addEventListeners() {
//     let btns = document.getElementsByClassName("importancebtn");

//     for (let btn of btns) {
//         // console.log(btn);
//         // btn.addEventListener("click", MyEvent);
//     }​
// }

function MyEvent() {
    // task[i].importance++;
    // console.log(task[i].importance);
    alert('hi')
        // document.getElementsByClassName("importance")[i].innerHTML = task[i].importance;
}